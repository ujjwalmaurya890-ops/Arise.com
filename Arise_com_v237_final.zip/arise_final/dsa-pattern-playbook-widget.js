/* dsa-pattern-playbook-widget.js — Pattern Playbook + constraint→complexity guide + complexity cheat sheet.
 * Static reference content, joined with YOUR progress: solved problems per pattern come from the
 * dsaProblemInsights tags (Problem Insights widget). Read-only, no storage key of its own. */
(function () {
  if (window.__ARISE_DSA_PLAYBOOK__) return;
  window.__ARISE_DSA_PLAYBOOK__ = true;
  var MOUNT = 'dpb-playbook', STYLE = 'dpb-playbook-style';
  var U = window.__ARISE_WIDGET_UTILS__ || {};
  var open = { 'sec:constraints': true }; // remembered across re-renders

  var PATTERNS = [
    { n: 'Two Pointers', cue: 'Sorted array/string, pair or triplet with a target, reverse/partition in place.', idea: 'Start pointers at both ends (or slow/fast); move the one that brings you closer to the goal.', big: 'O(n) after sorting', ex: 'Two Sum II, 3Sum, Container With Most Water' },
    { n: 'Sliding Window', cue: 'Longest/shortest/max/min contiguous subarray or substring under a condition.', idea: 'Grow the right edge; while the window is invalid, shrink from the left; record the best.', big: 'O(n)', ex: 'Longest Substring Without Repeating Characters, Minimum Window Substring' },
    { n: 'Fast & Slow Pointers', cue: 'Linked-list cycle, middle node, "find the duplicate" with O(1) space.', idea: 'Slow moves 1 step, fast moves 2; they meet iff there is a cycle.', big: 'O(n) time, O(1) space', ex: 'Linked List Cycle, Middle of the Linked List, Find the Duplicate Number' },
    { n: 'Binary Search', cue: 'Sorted data, or "minimum X such that condition holds" (answer is monotonic).', idea: 'Binary-search the index or the answer; keep lo/hi invariant clear and pick the mid rounding deliberately.', big: 'O(log n) (× cost of the check)', ex: 'Search in Rotated Sorted Array, Koko Eating Bananas, Capacity To Ship Packages' },
    { n: 'Prefix Sum', cue: 'Many range-sum queries, or count subarrays with a given sum.', idea: 'prefix[i] = sum of first i items; sum(l..r) = prefix[r+1] − prefix[l]. With a hash map of seen prefixes you can count subarrays in one pass.', big: 'O(n) build, O(1) query', ex: 'Subarray Sum Equals K, Range Sum Query, Product of Array Except Self' },
    { n: 'Monotonic Stack', cue: '"Next greater/smaller element", spans, histogram areas.', idea: 'Keep a stack whose values are monotonic; pop while the new element breaks the order and resolve the popped ones.', big: 'O(n)', ex: 'Daily Temperatures, Next Greater Element, Largest Rectangle in Histogram' },
    { n: 'BFS', cue: 'Shortest path in an unweighted graph/grid, level-by-level order, minimum steps.', idea: 'Queue + visited set; process one level at a time; the first time you reach a node is its shortest distance.', big: 'O(V + E)', ex: 'Binary Tree Level Order Traversal, Rotting Oranges, Word Ladder' },
    { n: 'DFS', cue: 'Explore all paths/components, tree recursion, flood fill, cycle detection.', idea: 'Recurse (or use a stack) with a visited set; return a value up from children to combine results.', big: 'O(V + E)', ex: 'Number of Islands, Path Sum, Clone Graph' },
    { n: 'Backtracking', cue: 'Generate all subsets/permutations/combinations, place items under constraints.', idea: 'Choose → explore → un-choose. Prune early when a partial answer can no longer be valid.', big: 'Exponential (O(2ⁿ) or O(n!))', ex: 'Subsets, Permutations, N-Queens' },
    { n: 'Dynamic Programming', cue: 'Overlapping subproblems + optimal substructure; "count ways", "min/max cost", "is it possible".', idea: 'Define state, write the recurrence, set base cases, then memoize (top-down) or fill a table (bottom-up); compress space if only the last row/few states are needed.', big: 'O(#states × transition cost)', ex: 'Climbing Stairs, Coin Change, Longest Common Subsequence' },
    { n: 'Greedy', cue: 'A locally best choice provably leads to a global best; often after sorting.', idea: 'Sort by the right key, take the best available choice, and be ready to justify why it never hurts (exchange argument).', big: 'Usually O(n log n)', ex: 'Jump Game, Gas Station, Assign Cookies' },
    { n: 'Heap / Priority Queue', cue: 'Top-K, running median, repeatedly "take the smallest/largest", merging sorted streams.', idea: 'Keep a heap of size K (min-heap for K largest); push/pop are O(log K).', big: 'O(n log K)', ex: 'Kth Largest Element in an Array, Top K Frequent Elements, Merge k Sorted Lists' },
    { n: 'Union Find', cue: 'Connected components, "are these connected?", merging groups, detecting a cycle in an undirected graph.', idea: 'Parent array with path compression + union by rank/size.', big: 'Near O(1) per op (inverse Ackermann)', ex: 'Number of Provinces, Redundant Connection, Accounts Merge' },
    { n: 'Topological Sort', cue: 'Dependencies/prerequisites in a directed graph; ordering tasks; detect cycles in a DAG.', idea: "Kahn's algorithm: repeatedly take nodes with in-degree 0; if you can't take all nodes, there is a cycle.", big: 'O(V + E)', ex: 'Course Schedule, Course Schedule II, Alien Dictionary' }
  ];
  var LIMITS = [
    ['n ≤ 10', 'O(n!)', 'Try all permutations / brute force'],
    ['n ≤ 20', 'O(2ⁿ)', 'Bitmask, subsets, backtracking'],
    ['n ≤ 500', 'O(n³)', 'Triple loop, Floyd–Warshall'],
    ['n ≤ 5,000', 'O(n²)', 'Nested loops, 2-D DP'],
    ['n ≤ 10⁵', 'O(n log n)', 'Sorting, heap, binary search, segment tree'],
    ['n ≤ 10⁶', 'O(n)', 'Single pass, hashing, two pointers (O(n log n) may still fit)'],
    ['n ≥ 10⁹', 'O(log n) / O(1)', 'Math formula, binary search on the answer']
  ];
  var CHEAT = [
    ['Sorting', [['Bubble / Selection', 'O(n²)', 'O(1)'], ['Insertion', 'O(n²), best O(n)', 'O(1)'], ['Merge sort', 'O(n log n)', 'O(n), stable'], ['Quick sort', 'avg O(n log n), worst O(n²)', 'O(log n)'], ['Heap sort', 'O(n log n)', 'O(1)'], ['Counting sort', 'O(n + k)', 'O(k)']]],
    ['Data structures', [['Array: access / search', 'O(1) / O(n)', ''], ['Dynamic array: push at end', 'O(1) amortized', ''], ['Linked list: access / insert at known node', 'O(n) / O(1)', ''], ['Hash map: get / put', 'avg O(1), worst O(n)', ''], ['Balanced BST: search / insert', 'O(log n)', ''], ['Heap: push / pop / peek', 'O(log n) / O(log n) / O(1)', ''], ['Stack / Queue: push / pop', 'O(1)', ''], ['Trie: insert / search word of length L', 'O(L)', '']]],
    ['Graphs', [['BFS / DFS', 'O(V + E)', 'O(V)'], ['Dijkstra (binary heap)', 'O((V + E) log V)', 'O(V)'], ['Topological sort', 'O(V + E)', 'O(V)']]]
  ];

  function get(k, fb) { try { var v = localStorage.getItem(k); if (v == null) return fb; var p = JSON.parse(v); return p == null ? fb : p; } catch (e) { return fb; } }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  function progress() {
    var qs = get('dsaQuestions', []), ins = get('dsaProblemInsights', {}), out = {};
    if (!Array.isArray(qs) || !ins || typeof ins !== 'object') return out;
    qs.forEach(function (q) {
      if (!q || !q.solved) return;
      var r = ins[q.id]; if (!r || !r.pattern) return;
      var o = out[r.pattern] || (out[r.pattern] = { solved: 0, unaided: 0 });
      o.solved++; if (r.quality === 'unaided') o.unaided++;
    });
    return out;
  }

  function css() {
    if (document.getElementById(STYLE)) return;
    var s = document.createElement('style'); s.id = STYLE;
    s.textContent = [
      '.dpb-block{position:relative;z-index:1;display:flex;flex-direction:column;gap:.6rem}',
      '.dpb-title{font-family:var(--font-display);font-weight:800;font-size:.95rem;color:var(--text-primary,#f1f5ff)}',
      '.dpb-sub{font-size:.74rem;color:var(--text-secondary,#8b93b0);line-height:1.5}',
      '.dpb-sec,.dpb-pat{border:1px solid var(--border-soft,rgba(255,255,255,.08));border-radius:.85rem;background:var(--surface-soft,rgba(255,255,255,.03));padding:.1rem .8rem}',
      '.dpb-sec>summary,.dpb-pat>summary{cursor:pointer;padding:.65rem 0;font-size:.8rem;font-weight:700;color:var(--text-primary,#f1f5ff);display:flex;justify-content:space-between;gap:.5rem;list-style:none}',
      '.dpb-sec>summary:focus-visible,.dpb-pat>summary:focus-visible{outline:2px solid var(--accent,var(--info));outline-offset:2px}',
      '.dpb-pat{margin:.4rem 0;background:transparent}',
      '.dpb-body{font-size:.74rem;line-height:1.55;color:var(--text-secondary,#8b93b0);padding-bottom:.7rem}',
      '.dpb-body b{color:var(--text-primary,#f1f5ff)}',
      '.dpb-me{font-size:.64rem;font-weight:700;padding:.15rem .5rem;border-radius:999px;border:1px solid var(--border-soft,rgba(255,255,255,.14));color:var(--text-secondary,#8b93b0);white-space:nowrap}',
      '.dpb-me.has{color:var(--success);border-color:color-mix(in srgb,var(--success) 45%,transparent)}',
      '.dpb-tbl{width:100%;border-collapse:collapse;font-size:.72rem;margin-bottom:.6rem}',
      '.dpb-tbl th,.dpb-tbl td{text-align:left;padding:.35rem .4rem;border-bottom:1px solid var(--border-soft,rgba(255,255,255,.07));color:var(--text-secondary,#8b93b0)}',
      '.dpb-tbl th{color:var(--text-primary,#f1f5ff)}',
      '.dpb-scroll{overflow-x:auto}',
      "[data-theme-mode='light'] .dpb-title,[data-theme-mode='light'] .dpb-sec>summary,[data-theme-mode='light'] .dpb-pat>summary,[data-theme-mode='light'] .dpb-body b,[data-theme-mode='light'] .dpb-tbl th{color:var(--text-primary,#000)}",
      "[data-theme-mode='light'] .dpb-sub,[data-theme-mode='light'] .dpb-body,[data-theme-mode='light'] .dpb-tbl td,[data-theme-mode='light'] .dpb-me{color:var(--text-secondary,#444)}"
    ].join('');
    document.head.appendChild(s);
  }

  function det(cls, key, summary, body) {
    return '<details class="' + cls + '" data-dpb-key="' + esc(key) + '"' + (open[key] ? ' open' : '') + '><summary>' + summary + '</summary>' + body + '</details>';
  }

  function build() {
    var prog = progress();
    var pats = PATTERNS.map(function (p) {
      var me = prog[p.n], badge = me ? '<span class="dpb-me has">' + me.solved + ' solved' + (me.unaided ? ' · ' + me.unaided + ' unaided' : '') + '</span>' : '<span class="dpb-me">0 tagged</span>';
      return det('dpb-pat', 'pat:' + p.n, '<span>' + esc(p.n) + '</span>' + badge,
        '<div class="dpb-body"><b>Look for:</b> ' + esc(p.cue) + '<br><b>Idea:</b> ' + esc(p.idea) + '<br><b>Typical cost:</b> ' + esc(p.big) + '<br><b>Practice:</b> ' + esc(p.ex) + '</div>');
    }).join('');
    var lim = '<div class="dpb-scroll"><table class="dpb-tbl"><tr><th>Constraint</th><th>Target</th><th>Think</th></tr>' +
      LIMITS.map(function (r) { return '<tr><td>' + esc(r[0]) + '</td><td>' + esc(r[1]) + '</td><td>' + esc(r[2]) + '</td></tr>'; }).join('') + '</table></div>' +
      '<div class="dpb-body">Rule of thumb: about 10⁸ simple operations fit in ~1 second in C++/Java; Python is often 10–50× slower, so aim one step lower. Read the constraints <i>before</i> choosing an approach.</div>';
    var cheat = CHEAT.map(function (g) {
      return '<div class="dpb-scroll"><table class="dpb-tbl"><tr><th>' + esc(g[0]) + '</th><th>Time</th><th>Space</th></tr>' +
        g[1].map(function (r) { return '<tr><td>' + esc(r[0]) + '</td><td>' + esc(r[1]) + '</td><td>' + esc(r[2]) + '</td></tr>'; }).join('') + '</table></div>';
    }).join('');
    return '<div><div class="dpb-title">📚 Pattern Playbook</div><div class="dpb-sub">Most online-test problems are a handful of patterns in disguise. Learn to spot the cue, then reach for the template. Counts come from the pattern tags you set in Problem Insights.</div></div>' +
      det('dpb-sec', 'sec:constraints', '<span>⚖️ Read the constraints → pick the complexity</span>', lim) +
      det('dpb-sec', 'sec:patterns', '<span>🧩 ' + PATTERNS.length + ' core patterns</span>', pats) +
      det('dpb-sec', 'sec:cheat', '<span>📋 Complexity cheat sheet</span>', cheat);
  }

  function render() {
    css();
    var el = document.getElementById(MOUNT); if (!el) return;
    el.classList.add('dpb-block');
    var html = build();
    if (el.__dpbHtml === html && el.firstChild) return;
    el.__dpbHtml = html; el.innerHTML = html;
    if (!el.__dpbWired) {
      el.__dpbWired = true;
      el.addEventListener('click', function (e) {
        var sm = e.target.closest ? e.target.closest('summary') : null; if (!sm) return;
        var d = sm.parentElement, k = d && d.getAttribute('data-dpb-key'); if (!k) return;
        open[k] = !d.open; // click fires before the native toggle, so the new state is the inverse
        el.__dpbHtml = null; // the markup for "open" attributes changed; rebuild next render
      });
    }
  }

  window.__ARISE_DSA_PLAYBOOK_API__ = { PATTERNS: PATTERNS, progress: progress };
  if (U.bootUpdater) U.bootUpdater(render);
  else if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', render); else render();
})();
